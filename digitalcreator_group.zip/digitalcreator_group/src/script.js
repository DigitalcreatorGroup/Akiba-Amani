// script.js

// Show Services on button click
function showServices() {
    document.querySelector('#services').scrollIntoView({ behavior: 'smooth' });
}

// Form submission handling
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    const formMessage = document.getElementById('form-message');

    // Simple form validation
    if (name && email && message) {
        formMessage.textContent = "Thank you for contacting us, " + name + "! We'll get back to you shortly.";
        formMessage.style.color = "green";
        document.getElementById('contactForm').reset();
    } else {
        formMessage.textContent = "Please fill out all fields.";
        formMessage.style.color = "red";
    }
});
